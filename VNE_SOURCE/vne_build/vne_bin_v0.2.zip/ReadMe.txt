VNE Version 0.2

Key Commands:

(operate on one object only now; the one with the most faces)

w  :  increase radius of rotation w/ constant period
s  :  decrease radius of rotation w/ constant period
e  :  increase spin speed
d  :  decrease spin speed
x  :  spin about x-axis
y  :  spin about y-axis
z  :  spin about z-axis

i  :  move object up
k  :  move object down
j  :  move object left
l  :  move object right

Cool effect: hold down "w" for a bit so the object is moving, you'll see it ricochet
off the walls nicely.

Then use i/j/k/l to adjust its position so it gets into a cool bouncing path.

Try changing its spin speed with e & d or its axis of rotation with x/y/z