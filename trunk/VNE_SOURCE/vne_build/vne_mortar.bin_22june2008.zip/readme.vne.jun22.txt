Welcome to VNE Mortar version 22 june 2008 !!

Goal: Destroy the other player's mortar by hitting it with a shell.

Key Commands:
"1" Focus on mortar 1
"2" Focus on mortar 2
"g" Attach camera to focused mortar
"=" increase power large increment
"+" increase power fine increment
"-" decrease power large increment
"_" decrease power fine increment
"shift-r" reset game
"f" fire focused mortar
"c" computer tells you the minimum possible kinetic energy to hit the target

rotation keys: "v,b,n" and shift-"v,b,n"
movement: "i,j,k,l" (you can only move in the plane)

note: after a mortar fires, focus automatically switches to the other player

currently there is known instability with floor collisions, but it is tolerable...
