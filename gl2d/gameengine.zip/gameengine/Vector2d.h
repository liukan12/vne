#ifndef VECTOR2D_H
#define VECTOR2D_H
#define PI 3.14159265
struct Vector2d
{
public:
	float x;
	float y;
	
	Vector2d operator-(Vector2d subVec);
	Vector2d operator+( Vector2d subVec);
	Vector2d operator+=( Vector2d subVec);
	Vector2d operator-=( Vector2d subVec);
	
	void set(float nX,float nY);
	void Scale(float xScale, float yScale);
	void Rotate(float angle);
	void Translate(Vector2d xy);

};
#endif
