#ifndef IMAGES_H
#define IMAGES_H
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <SOIL.h>
#include <string>
#include <map>


class Images
{
private:
	std::map<std::string,GLuint> imageMap;
public:
	void LoadImage(std::string name, std::string filename);
	GLuint GetImage(std::string name); 

};


#endif