#include "Images.h"
using namespace std;

void Images::LoadImage(string name, string filename)
{

	GLuint image = SOIL_load_OGL_texture
	(
		filename.c_str(),
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y|SOIL_FLAG_MULTIPLY_ALPHA
	);
	imageMap.insert(pair<string,GLuint>(name,image));
}
GLuint Images::GetImage(string name)
{
	return imageMap[name];
}