#include "Vector2d.h"
#include <cmath>
using namespace std;
Vector2d Vector2d::operator-( Vector2d subVec)
{
	Vector2d result;
	result.x= x-subVec.x;
	result.y= y-subVec.y;
	return result;
	
	
}
Vector2d Vector2d::operator+=( Vector2d subVec)
{
	x+=subVec.x;
	y+=subVec.y;
	return (*this);
}
Vector2d Vector2d::operator-=( Vector2d subVec)
{
	
	x-=subVec.x;
	y-=subVec.y;
	return (*this);

}
Vector2d Vector2d::operator+( Vector2d subVec)
{
	Vector2d result;
	result.x= x+subVec.x;
	result.y= y+subVec.y;
	return result;
	
}

void Vector2d::set(float nX,float nY)
{
	x=nX;
	y=nY;
}
void Vector2d::Scale(float xScale, float yScale)
{
	x=x*xScale;
	y=y*yScale;
}
void Vector2d::Rotate(float angle)
{
	
	static float rotM[4];
	static float tx,ty;
	rotM[0]=cosf(angle*PI/180.0);
	rotM[1]=-sinf(angle*PI/180.0);
	rotM[2]=-rotM[1];
	rotM[3]=rotM[0];
	tx=x*rotM[0]+y*rotM[1];
	ty=x*rotM[2]+y*rotM[3];
	x=tx;
	y=ty;
}
void Vector2d::Translate(Vector2d xy)
{
	(*this)+=xy;
}
