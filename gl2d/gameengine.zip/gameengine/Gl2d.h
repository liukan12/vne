#ifndef GL2D
#define GL2D
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include "Sprite.h"
#include "Vector2d.h"
#include "Images.h"
class Gl2d
{
private:
	Sprite* testSprite;
	Sprite* testSprite2;
	bool left,right,up,down;
	static const int NO_INTERSECTION=0;
	bool Gl2d::edgeIntersection(Vector2d a, Vector2d b, Vector2d c, Vector2d d);
	float Gl2d::determinant(Vector2d vec1, Vector2d vec2);
	Images* images;
public:
	Gl2d();
	~Gl2d();

	//drawing functions go in this function
	void display();

	//game logic goes here
	void update();

	//window stuff 
	void reshape(int w, int h);

	//mouse functions
	void motionPassive(int x, int y);
	void motion(int x, int y);
	void mouse(int button, int state, int x, int y);

	//keyboard
	void keyboard(unsigned char key, int x, int y);
	void keyboardup(unsigned char key, int x, int y);
	void special(int key, int x, int y);
};
#endif 
