#include "CollisionPoly.h"
CollisionPoly::CollisionPoly(int num)
{
	numPoints=num;
	this->points=new Vector2d[numPoints];
}