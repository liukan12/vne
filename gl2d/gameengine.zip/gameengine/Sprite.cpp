#include "Sprite.h"
using namespace std;
Sprite::Sprite(GLuint nImage)
{
	
	image = nImage;
	GLint w,h;
	glGetTexLevelParameteriv(GL_TEXTURE_2D,0,GL_TEXTURE_WIDTH,&w);
	glGetTexLevelParameteriv(GL_TEXTURE_2D,0,GL_TEXTURE_HEIGHT,&h);
	width=w;
	height=h;
	cout<<"width:"<< width<<"height:"<<height<<endl;

	position.x=0;
	position.y=0;

	rotation=0;
	setVertices();
	setTexVertices();
	drawCollision=true;
}
Sprite::~Sprite()
{
}
void Sprite::setVertices()
{
	vertices[0].x=0.0;
	vertices[0].y=0.0;
	vertices[1].x=width;
	vertices[1].y=0.0;
	vertices[2].x=width;
	vertices[2].y=height;
	vertices[3].x=0.0;
	vertices[3].y=height;
	

}
void Sprite::setTexVertices()
{
	texVertices[0].x=0.0;
	texVertices[0].y=0.0;
	texVertices[1].x=1.0;
	texVertices[1].y=0.0;
	texVertices[2].x=1.0;
	texVertices[2].y=1.0;
	texVertices[3].x=0.0;
	texVertices[3].y=1.0;
}
void Sprite::SetCollisionPoly(Vector2d *poly, int length)
{
	oriPoly=new CollisionPoly(length);
	this->collPoly=new CollisionPoly(length);
	for(int i=0;i<length;i++)
	{
		collPoly->points[i]=poly[i];
		oriPoly->points[i]=poly[i];
	}
}
CollisionPoly* Sprite::GetCollisionPoly()
{
	UpdateCollisionPoly();
	return collPoly;
}
void Sprite::UpdateCollisionPoly()
{
	for(int i=0; i<collPoly->numPoints;i++)
	{
		collPoly->points[i]=oriPoly->points[i];
		collPoly->points[i].Rotate(rotation);
		collPoly->points[i].Translate(position);
		
	}
}
void Sprite::Draw()
{
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,image);
    glPushMatrix();
		glLoadIdentity();
		glTranslatef(position.x,position.y,0);
		
		
		glRotatef(rotation,0.0,0.0,1.0);
		//glTranslatef(-(width/2.0),-(height/2.0),0.0);
		
		
		glColor4f(1.0,1.0,1.0,1.0);
		glBegin(GL_QUADS);
			for(int i=0; i<4; i++)
			{
				glTexCoord2f(texVertices[i].x,texVertices[i].y); 
				glVertex2f(vertices[i].x,vertices[i].y);
			}
		glEnd();
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
	if(drawCollision)
	{
		glLoadIdentity();
		glColor3f(1.0,0.0,1.0);
		glBegin(GL_LINE_STRIP);
		for(int i=0; i<collPoly->numPoints; i++)
			{
				
				glVertex2f(collPoly->points[i].x,collPoly->points[i].y);
			}
		glEnd();
	}
	
}
void Sprite::Draw(float x, float y)
{
	position.x=x;
	position.y=y;
	
	this->Draw();
}
void Sprite::SetPosition(float x, float y)
{
	position.x=x;
	position.y=y;
	
}
void Sprite::SetRotation(float angle)
{

	rotation=angle;
	
}
void Sprite::SetWidth(float w)
{
	width=w;
	setVertices();
	
}
void Sprite::SetHeight(float h)
{
	height=h;
	setVertices();
	
}
float Sprite::Width()
{
	return width;
}
float Sprite::Height()
{
	return height;
}

void  Sprite::GetDimensions(float *dimensionsV)
{
	dimensionsV[0]=width;
	dimensionsV[1]=height;
}
void Sprite::Scale(float scaleX, float scaleY)
{
	width*=scaleX;
	height*=scaleY;
	setVertices();
	
}