this project depents on these glut32.lib opengl32.lib glu32.lib SOIL.lib
make sure you have glut, opengl, and soil
soil is available here:
http://www.lonesock.net/soil.html
glut is available here:
http://www.opengl.org/resources/libraries/glut/glut_downloads.php
i'm not sure where to get opengl, it may come on your computer!
use a,w,s,d to move around the head.