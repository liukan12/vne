#ifndef COLLISIONPOLY_H
#define COLLISIONPOLY_H
#include "Vector2d.h"

class CollisionPoly
{
public:
	int numPoints;
	Vector2d* points;
	CollisionPoly(int num);
};
#endif