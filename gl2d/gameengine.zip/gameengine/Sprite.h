#ifndef SPRITE_H
#define SPRITE_H
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <SOIL.h>
#include <iostream>
#include <string>
#include "Vector2d.h"
#include "CollisionPoly.h"


class Sprite
{
private:
	
	Vector2d vertices[4];
	Vector2d texVertices[4];
	void UpdateCollisionPoly();	
	GLuint image;
	float width, height;
	CollisionPoly* collPoly;
	CollisionPoly* oriPoly;
public:
	
	Vector2d position;
	float rotation;
	Sprite(GLuint nImage);
	~Sprite();
	bool drawCollision;
	void setVertices();
	void setTexVertices();
	void Draw();
	void Draw(float x, float y);
	void SetPosition(float x, float y);
	void SetRotation(float angle);
	void SetWidth(float w);
	void SetHeight(float h);
	float Width();
	float Height();
	CollisionPoly* GetCollisionPoly();
	void SetCollisionPoly(Vector2d *poly, int length);
	
	void  GetDimensions(float *dimensionsV);
	void Scale(float scaleX, float scaleY);
	
};
#endif
