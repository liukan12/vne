#include "Gl2d.h"
#include <iostream>
using namespace std;

Gl2d::Gl2d()
{
	images= new Images();
	images->LoadImageA("testsprite","test.png");

	testSprite2=new Sprite(images->GetImage("testsprite"));
	testSprite2->SetPosition(500,400);
	testSprite=new Sprite(images->GetImage("testsprite"));
	glClearColor (0.0, 0.0, 0.0, 0.0);
	testSprite->SetPosition(200,200);
	right=false;
	left=false;
	up=false;
	down=false;
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	Vector2d colP[6];
	colP[0].set(13,1);
	colP[1].set(4,60);
	colP[2].set(32,84);
	colP[3].set(57,58);
	colP[4].set(41,5);
	colP[5].set(13,1);
	testSprite->SetCollisionPoly(colP,6);
	testSprite2->SetCollisionPoly(colP,6);
	//testSprite2->drawCollision=false;

}

Gl2d::~Gl2d()
{
}

//drawing functions go in this function
void Gl2d::display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	testSprite->Draw();
	testSprite2->Draw();
	glFlush();
	glutSwapBuffers();
	
}
float Gl2d::determinant(Vector2d vec1, Vector2d vec2){
    return vec1.x*vec2.y-vec1.y*vec2.x;
}
 
//one edge is a-b, the other is c-d
bool Gl2d::edgeIntersection(Vector2d a, Vector2d b, Vector2d c, Vector2d d){
    float det=determinant(b-a,c-d);
    float t=determinant(c-a,c-d)/det;
    float u=determinant(b-a,c-a)/det;
    if ((t<0.0)||(u<0.0)||(t>1.0)||(u>1.0))return false;
    return true;
}
//game logic goes here
void Gl2d::update()
{
	testSprite->rotation+=2;
	if(testSprite->rotation>360)
		testSprite->rotation=0;
	if(left)
		testSprite->position.x-=2;
	if(right)
		testSprite->position.x+=2;
	if(up)
		testSprite->position.y+=2;
	if(down)
		testSprite->position.y-=2;
	//static Vector2d v1[5];
	//static Vector2d v2[5];
	//testSprite->GetWorldVertices(v1);
	//testSprite2->GetWorldVertices(v2);
	static CollisionPoly* cp1;
	static CollisionPoly* cp2;
	static bool coll=false;
	cp1=testSprite->GetCollisionPoly();
	cp2=testSprite2->GetCollisionPoly();
	for(int i=0; i<cp1->numPoints-1;i++)
	{
		for(int t=0; t<cp2->numPoints-1;t++)
		{
			if(edgeIntersection(cp1->points[i],cp1->points[i+1],cp2->points[t],cp2->points[t+1]))
			{
				cout<<"collision!"<<endl;
				coll=true;
				break;
			}else coll=false;
		}
		if(coll)break;
	}

}

//window stuff 
void Gl2d::reshape(int w, int h)
{
	glViewport(0, 0, w, h);		// reset the viewport to new dimensions
	glMatrixMode(GL_PROJECTION);			// set projection matrix current matrix
	glLoadIdentity();						// reset projection matrix

	// calculate aspect ratio of window
	glOrtho(0.0f, (float)w - 1.0, 0.0, (float)h - 1.0, -1.0, 1.0);

	glMatrixMode(GL_MODELVIEW);				// set modelview matrix
	glLoadIdentity();
}

//mouse functions
void Gl2d::motionPassive(int x, int y)
{
}
void Gl2d::motion(int x, int y)
{
}
void Gl2d::mouse(int button, int state, int x, int y)
{
}
void Gl2d::keyboard(unsigned char key, int x, int y)
{
	switch(key)
	{
	// Backspace
	case 'a' :
		left=true;
		break;

	// Enter
	case 'd' :
		right=true;
		break;

	// Escape
	case 's':
		down=true;
		break;

	// Delete
	case 'w' :
		up=true;
		break;
	default:
		break;
	}
}
void Gl2d::keyboardup(unsigned char key, int x, int y)
{
	switch(key)
	{
	// Backspace
	case 'a' :
		left=false;
		break;

	// Enter
	case 'd' :
		right=false;
		break;

	// Escape
	case 's':
		down=false;
		break;

	// Delete
	case 'w' :
		up=false;
		break;
	default:
		break;
	}
}
void Gl2d::special(int key, int x, int y)
	{
	}